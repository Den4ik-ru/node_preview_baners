(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_1", frames: [[0,0,460,357],[462,0,350,350]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.dis2 = function() {
	this.initialize(ss["index_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.prod = function() {
	this.initialize(ss["index_atlas_P_1"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.uiArea = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(51,51,51,0.008)").s().p("AnzH0IAAvnIPnAAIAAPng");
	this.shape.setTransform(-0.2,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.2,-50,100,100);


(lib.textPromo2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA+BtIgRgtIhcAAIgRAtIgyAAIBXjYIA2AAIBYDYgAAbASIgbhIIgcBIIA3AAg");
	this.shape.setTransform(57.425,13.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AApBtIg/hZIgfAAIAABZIgyAAIAAjYIAyAAIAABVIAdAAIA3hVIA6AAIhIBlIBXBzg");
	this.shape_1.setTransform(34.65,13.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhaBtIAAjYIBhAAQAoAAATAOQASAOAAAbQABASgIALQgGAMgQAHQAkAIAAApQAAARgGAMQgGAMgLAIQgLAIgQADQgPAEgUAAgAgoA+IAwAAQASAAAHgFQAIgHAAgLQAAgKgIgGQgHgFgSAAIgwAAgAgogUIArAAQARAAAIgFQAGgHABgJQAAgJgHgGQgHgFgRAAIgsAAg");
	this.shape_2.setTransform(11.45,13.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AA+BtIgRgtIhcAAIgRAtIgyAAIBXjYIA2AAIBYDYgAAbASIgbhIIgcBIIA3AAg");
	this.shape_3.setTransform(-11.925,13.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgZBtIAAiqIhCAAIAAguIC3AAIAAAuIhFAAIAACqg");
	this.shape_4.setTransform(-31.225,13.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgZBoQgXgHgQgPQgQgOgJgVQgJgVAAgaQAAgZAJgUQAJgVAQgPQAQgOAXgIQAWgIAbAAQAYAAASAFQATAFALAHIAABAIgNgNQgHgHgJgEQgJgFgLgDQgLgDgMAAQgQAAgMAFQgNAFgIAIQgJAJgFAMQgFAMAAAOQAAANAFAMQAEAMAIAJQAJAJANAFQAMAFARAAQAbAAATgJQATgKAKgPIAAA3QgEAFgHAFQgIAEgJAEQgKAEgMACQgMACgOAAQgaAAgWgIg");
	this.shape_5.setTransform(-52.125,13.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgvBoQgWgHgPgOQgRgPgIgVQgJgVAAgaQAAgZAJgUQAIgVAQgPQAPgOAXgIQAVgIAaAAQAaAAAWAHQAVAHARAPQAPAOAJAVQAJAVAAAaQAAAZgJAVQgIAUgQAPQgQAPgVAIQgXAIgaAAQgZAAgWgIgAgbg8QgMAFgJAIQgIAJgFAMQgFAMABAOQgBANAFAMQAEAMAJAJQAIAJAMAFQAMAFAQAAQAPAAAMgEQANgFAJgJQAIgIAFgMQAFgMAAgPQAAgNgFgMQgEgMgIgIQgJgJgNgGQgMgFgQAAQgPAAgMAFg");
	this.shape_6.setTransform(-75.9,13.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ABCCBIAAgpIiCAAIAAApIgvAAIAAhXIAWAAIAIgXIAGgaIAEghIACgrIABgtICeAAIAACqIAWAAIAABXgAgYgrIgDAgIgGAbIgHAaIBQAAIAAh7Ig+AAg");
	this.shape_7.setTransform(-100.525,15.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAqBsIAAg8IgaAAIgIAAIgHgBIgjA9Ig5AAIAthGQgWgJgKgRQgJgPAAgZQAAgoAagUQAagUAyAAIBNAAIAADYgAgYg1QgMAIAAARQAAAPAKAIQAKAGAXAAIAjAAIAAg+IghAAQgWAAgLAIg");
	this.shape_8.setTransform(100.125,-16.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AA+BsIgRgsIhcAAIgRAsIgyAAIBXjYIA2AAIBYDYgAAbARIgbhHIgcBHIA3AAg");
	this.shape_9.setTransform(78.025,-16.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AA0BsIAAhYIhnAAIAABYIgyAAIAAjYIAyAAIAABSIBnAAIAAhSIAyAAIAADYg");
	this.shape_10.setTransform(53.525,-16.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgZBsIAAipIhCAAIAAgvIC3AAIAAAvIhFAAIAACpg");
	this.shape_11.setTransform(31.025,-16.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AA+BsIgRgsIhcAAIgRAsIgyAAIBXjYIA2AAIBYDYgAAbARIgbhHIgcBHIA3AAg");
	this.shape_12.setTransform(11.725,-16.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AheBtIgKgDIAAgxIAFACIAFAAIAHgBQAEgBAEgEQADgEADgIQADgIADgOIAFghIADgyIADgtIChAAIAADYIgyAAIAAipIhCAAQgDAngDAbQgEAcgFATQgFAUgGAMQgGALgHAGQgHAGgIACQgIACgJAAg");
	this.shape_13.setTransform(-13.075,-16);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAyBsIAAipIhiAAIAACpIgyAAIAAjYIDFAAIAADYg");
	this.shape_14.setTransform(-36.375,-16.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgZBoQgXgHgQgPQgQgOgJgVQgJgVAAgaQAAgZAJgUQAJgVAQgPQAQgOAXgIQAWgIAbAAQAYAAASAFQATAFALAHIAABAIgNgNQgHgHgJgEQgJgFgLgDQgLgDgMAAQgQAAgMAFQgNAFgIAIQgJAJgFAMQgFAMAAAOQAAANAFAMQAEAMAIAJQAJAJANAFQAMAFARAAQAbAAATgJQATgKAKgPIAAA3QgEAFgHAFQgIAEgJAEQgKAEgMACQgMACgOAAQgaAAgWgIg");
	this.shape_15.setTransform(-59.825,-16.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhNBsIAAjYICYAAIAAAvIhmAAIAAAjIBaAAIAAAuIhaAAIAAAqIBpAAIAAAug");
	this.shape_16.setTransform(-79.95,-16.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AhZBsIAAjYICeAAIAAAvIhsAAIAAAcIApAAQBYAAAABEQAAASgHAOQgHANgMAKQgMAJgRAFQgQAEgTAAgAgnA+IAoAAIAOgBQAHgBAFgDQAGgDACgFQAEgFAAgJQAAgHgDgEQgCgFgFgCQgGgDgHAAIgOgCIgpAAg");
	this.shape_17.setTransform(-100.45,-16.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-114,-36.7,228.1,73.5);


(lib.textPromo1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AA+BsIgRgsIhcAAIgRAsIgyAAIBXjYIA2AAIBYDYgAAbARIgbhHIgcBHIA3AAg");
	this.shape.setTransform(36.975,28.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgZBsIAAipIhCAAIAAgvIC3AAIAAAvIhFAAIAACpg");
	this.shape_1.setTransform(17.675,28.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgZBoQgXgHgQgPQgQgOgJgVQgJgVAAgaQAAgZAJgUQAJgVAQgPQAQgOAXgIQAWgIAbAAQAYAAASAFQATAFALAHIAABAIgNgNQgHgHgJgEQgJgFgLgDQgLgDgMAAQgQAAgMAFQgNAFgIAIQgJAJgFAMQgFAMAAAOQAAANAFAMQAEAMAIAJQAJAJANAFQAMAFARAAQAbAAATgJQATgKAKgPIAAA3QgEAFgHAFQgIAEgJAEQgKAEgMACQgMACgOAAQgaAAgWgIg");
	this.shape_2.setTransform(-3.225,28.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgvBoQgWgHgQgOQgQgPgIgVQgJgVAAgaQAAgZAIgUQAJgVAQgPQAQgOAVgIQAXgIAZAAQAaAAAWAHQAWAHAPAPQARAOAIAVQAJAVAAAaQAAAZgIAVQgKAUgPAPQgQAPgVAIQgXAIgZAAQgaAAgWgIgAgbg8QgNAFgIAIQgJAJgEAMQgEAMgBAOQABANAEAMQAEAMAIAJQAJAJAMAFQAMAFARAAQAPAAAMgEQAMgFAJgJQAJgIAEgMQAEgMABgPQgBgNgEgMQgEgMgJgIQgIgJgMgGQgMgFgRAAQgPAAgMAFg");
	this.shape_3.setTransform(-27,28.525);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AhYBsIAAjYIBLAAQAbAAATAGQAUAEANAKQAMAKAGAOQAEAPAAASQAAAngaAUQgaAUgxAAIgZAAIAAA8gAgmABIAeAAQAXAAALgHQALgIAAgRQAAgPgKgIQgJgHgXAAIghAAg");
	this.shape_4.setTransform(-50.15,28.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAyBsIAAipIhiAAIAACpIgyAAIAAjYIDFAAIAADYg");
	this.shape_5.setTransform(-74.025,28.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("ABEBtIAAjYIAyAAIAADYgAh1BtIAAjYIAyAAIAAA8IAQAAQAdABATAFQATAEANALQAMAJAFAOQAGANgBATQAAAogaAUQgZATgyABgAhDA+IAWAAQAYAAALgIQAKgIAAgRQAAgQgJgHQgKgGgXAAIgZAAg");
	this.shape_6.setTransform(44.55,-1.25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("ABCCBIAAgpIiCAAIAAApIgvAAIAAhXIAWAAIAIgXIAGgaIAEghIACgrIABgtICeAAIAACqIAWAAIAABXgAgYgrIgDAgIgGAbIgHAaIBQAAIAAh7Ig+AAg");
	this.shape_7.setTransform(18.275,0.775);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgvBoQgWgHgQgOQgPgPgJgVQgJgVAAgaQAAgZAJgUQAIgVAQgPQAQgOAVgIQAWgIAaAAQAaAAAWAHQAVAHAQAPQARAOAIAVQAJAVAAAaQAAAZgJAVQgJAUgPAPQgPAPgXAIQgVAIgaAAQgaAAgWgIgAgbg8QgMAFgJAIQgIAJgFAMQgFAMAAAOQAAANAFAMQAEAMAIAJQAJAJAMAFQANAFAQAAQAOAAANgEQAMgFAIgJQAKgIAEgMQAFgMgBgPQABgNgFgMQgEgMgJgIQgIgJgNgGQgMgFgQAAQgPAAgMAFg");
	this.shape_8.setTransform(-5.55,-1.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhKBtIAAjYICVAAIAAAuIhjAAIAACqg");
	this.shape_9.setTransform(-26,-1.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ABEBtIAAjYIAyAAIAADYgAh0BtIAAjYIAxAAIAAA8IAQAAQAcABAUAFQATAEANALQAMAJAFAOQAGANgBATQAAAogaAUQgZATgyABgAhDA+IAXAAQAXAAALgIQAKgIAAgRQAAgQgJgHQgKgGgXAAIgZAAg");
	this.shape_10.setTransform(-50.3,-1.25);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AhaBtIAAjYIBhAAQAoAAATAOQASAOAAAbQABASgIALQgGAMgQAHQAkAIAAApQAAARgGAMQgGAMgLAIQgLAIgQADQgPAEgTAAgAgoA+IAwAAQASAAAIgFQAHgHAAgKQAAgLgHgGQgIgFgSAAIgwAAgAgogUIArAAQARAAAIgFQAGgHABgJQAAgJgHgGQgHgFgRAAIgsAAg");
	this.shape_11.setTransform(-74.85,-1.25);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AA+BsIgRgsIhcAAIgRAsIgyAAIBXjYIA2AAIBYDYgAAbARIgbhHIgcBHIA3AAg");
	this.shape_12.setTransform(74.575,-31);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AheBtIgKgDIAAgxIAFACIAFAAIAHgBQAEgBAEgEQADgEADgIQADgIADgOIAFghIADgyIADgtIChAAIAADYIgyAAIAAipIhCAAQgDAngDAbQgEAcgFATQgFAUgGAMQgGALgHAGQgHAGgIACQgIACgJAAg");
	this.shape_13.setTransform(49.775,-30.85);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgtBsIgNgEIAAgxQAFAEAIACQAIACAIAAQAFAAADgBQAEgCACgDIhdimIA6AAIA7BtIAwhtIA0AAIhMCmQgHAQgHAKQgHAKgIAGQgHAGgIACQgIADgJAAQgJAAgIgCg");
	this.shape_14.setTransform(30.025,-30.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("ABJBsIAAiTIg6BiIgaAAIg9hiIAACTIgyAAIAAjYIBAAAIA8BpIA8hpIA9AAIAADYg");
	this.shape_15.setTransform(3.85,-31);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhXBsIAAjYIBKAAQAbAAATAGQAVAEAMAKQAMAKAGAOQAEAOAAASQAAAogaAUQgZAUgyAAIgZAAIAAA8gAgmABIAeAAQAYAAAKgHQAMgIAAgRQAAgPgLgIQgJgHgXAAIghAAg");
	this.shape_16.setTransform(-21.25,-31);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgvBoQgWgHgQgOQgPgPgJgVQgJgVAAgaQAAgZAJgUQAIgVAQgPQAPgOAXgIQAVgIAaAAQAaAAAWAHQAVAHAQAPQARAOAIAVQAJAVAAAaQAAAZgJAVQgIAUgQAPQgPAPgXAIQgVAIgbAAQgZAAgWgIgAgbg8QgMAFgJAIQgJAJgEAMQgFAMABAOQgBANAFAMQAEAMAIAJQAJAJAMAFQANAFAPAAQAPAAAMgEQANgFAIgJQAKgIAEgMQAFgMgBgPQABgNgFgMQgEgMgJgIQgIgJgNgGQgMgFgQAAQgPAAgMAFg");
	this.shape_17.setTransform(-45.5,-30.975);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgYBzIAAgVIgEAAQgyAAgagZQgbgaAAgsQAAgYAHgSQAHgRAOgMQAOgNATgGQAUgGAZAAIABAAIAAgRIAxAAIAAARIAEAAQAZAAATAGQATAHANAMQANANAHASQAHARAAAXQAAAXgHASQgHASgOAMQgNAMgUAGQgUAGgZAAIgBAAIAAAVgAAZAxIACAAQAMAAAJgCQAKgDAHgGQAHgGAEgKQADgKAAgOQAAgOgEgKQgFgKgHgFQgHgGgKgDQgJgCgKAAIgCAAgAgvgxQgKACgHAGQgHAGgEAKQgDAKAAAPQAAANAEAKQAEAKAIAGQAHAGAJACQAKACAKAAIACAAIAAhlIgCAAQgMAAgJADg");
	this.shape_18.setTransform(-72.425,-31.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-88.5,-51.6,177,103.30000000000001);


(lib.elSloganTextProfit = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("ACPAgIAOgBQAGgPACgQQACgUAAgdIgBgdIBngFIAEBtIAOAAIADA4IgeABIgBgaIhVADIABAaIgeACgADFgxQABAbgCASQgCASgGAQIA1gCIgDhPgAnAg2IA/gCQAygCABAkQABALgEAIQgFAHgKAFQAYAEABAbQACApg3ACIg+ADgAl9AYIggABIABAdIAggBQAMAAAEgEQAFgEAAgHQAAgHgGgDQgFgEgJAAIgCAAgAmCgaIgdACIABAZIAdgBQAKAAAFgEQAFgDAAgHQgBgMgSAAIgCAAgAkzg7IAggBIACAnIAKgBQAkgBAQAMQAQALABAYQACAzhDADIgqACgAkAAHIgQAAIACAqIAOgBQAPgBAHgFQAHgGAAgLQgBgJgGgFQgHgEgMAAIgDAAgAi7hAIAggBIAFCLIggABgAh6hDIBggDIACAeIhBACIAEBtIggACgAAHAzQgWgTgBghQgBghATgUQAUgVAjgBQAigCAWATQAWASABAiQACAggVAUQgUAVgiACIgFAAQgfAAgUgRgAA6gvQgUABgLANQgLAMABATQABARALALQAMAMAVAAQATgBALgNQALgMgBgRQAAgTgMgLQgLgMgUAAIgBAAgAFghWIAjgBIA+CIIgiABIgMgbIg8ACIgKAdIggACgAFigEIAkgCIgUgug");
	this.shape.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-44.9,-8.8,89.9,17.6);


(lib.elSloganTextMega = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1F1F1F").s().p("AkWg7IApgBIAqBAIAkhEIAngCIAGCMIggABIgEhgIgjBBIgSABIgpg9IADBeIggACgAhXhDIBigEIABAeIhBADIABAXIA6gDIABAeIg6ACIABAbIBEgDIABAeIhkAEgAAphIIBggEIABAeIhAADIAEBtIggABgAC2hOIAjgBIA+CJIghABIgNgcIg8ACIgKAdIggACgAC4ADIAlgCIgUgtg");
	this.shape.setTransform(-0.025,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-27.9,-8,55.8,16);


(lib.elPlate6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#410D6B").s().p("AvnfQQh8AAhYhYQhYhYAAh8MAAAg1HQAAh8BYhYQBYhYB8AAIfPAAQB8AABYBYQBYBYAAB8MAAAA1HQAAB8hYBYQhYBYh8AAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130,-200,260,400);


(lib.elPlate5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#551B85").s().p("AyvfQQh8AAhYhYQhYhYAAh8MAAAg1HQAAh8BYhYQBYhYB8AAMAlfAAAQB8AABYBYQBYBYAAB8MAAAA1HQAAB8hYBYQhYBYh8AAg");
	this.shape.setTransform(20,0);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130,-200,300,400);


(lib.elPlate4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#6A28A0").s().p("AvnfQQh8AAhYhYQhYhYAAh8MAAAg1HQAAh8BYhYQBYhYB8AAIfPAAQB8AABYBYQBYBYAAB8MAAAA1HQAAB8hYBYQhYBYh8AAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130,-200,260,400);


(lib.elPlate3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#7B36BA").s().p("AvnfQQh8AAhYhYQhYhYAAh8MAAAg1HQAAh8BYhYQBYhYB8AAIfPAAQB8AABYBYQBYBYAAB8MAAAA1HQAAB8hYBYQhYBYh8AAg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130,-200,260,400);


(lib.elProduct = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// CENTER
	this.instance = new lib.prod();
	this.instance.setTransform(-125,-125,0.7143,0.7143);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-125,-125,250,250);


(lib.elDiscount = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// CENTER
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,0,0,0.004)").s().p("AAVBOQgLgKAAgVQAAgVAMgJQANgKAUAAQAJAAAIACQAHADAFAEQAGAFAEAIQACAIAAAKQAAAVgMAKQgMAKgVAAQgSAAgMgKgAAqAmQgDAEAAAFQAAAHAEADQAEAEAHAAQANAAAAgOQAAgFgDgEQgDgEgHAAQgIAAgEAEgAhPBWIB8isIAjAAIh7CsgAhVgQQgLgKABgUQgBgWAMgJQAMgKAWAAQAJAAAHACQAIACAFAFQAGAFADAIQADAIAAALQAAAKgEAIQgCAIgHAEQgFAFgJADQgIACgKAAQgTAAgMgKgAg/g4QgDADgBAHQAAAGAFAEQADADAIAAQANAAgBgNQAAgHgCgDQgDgDgIgBQgHABgEADg");
	this.shape.setTransform(14.5,-0.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(0,0,0,0.004)").s().p("AAABXIAAiAIgjAWIAAgnIArgcIAcAAIAACtg");
	this.shape_1.setTransform(-1.55,-0.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(0,0,0,0.004)").s().p("AgYBTQgNgFgKgLQgJgKgGgQQgFgPAAgVQAAgXAFgRQAGgSAKgLQAKgLANgGQAOgGAOAAQAKgBAIACQAJABAHADIALAGIAHAFIAAAqIgJgHIgMgHQgHgDgHgBQgIgCgIABQgPACgKAKQgKALAAASIAAACQAFgLALgHQALgGAOAAQANAAALAEQAKAFAHAHQAIAIADAKQAEAKAAAMQAAAPgFALQgFALgJAIQgJAIgMAEQgMAEgNAAQgOAAgNgFgAgRAMQgIAGgBALQADAKAHAFQAGAFALAAQAHAAAFgCQAFgCADgDQADgDACgEIABgHQAAgJgGgHQgGgGgOAAQgKAAgIAGg");
	this.shape_2.setTransform(-12.775,-0.1312);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(0,0,0,0.004)").s().p("AggAQIAAgfIBBAAIAAAfg");
	this.shape_3.setTransform(-24.4,1.175);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("rgba(255,255,255,0)").s().p("AlPE7QiCAAhchcQhchcAAiDIAAAAQAAiCBchcQBchcCCAAIKfAAQCCAABcBcQBcBcAACCIAAAAQAACDhcBcQhcBciCAAg");
	this.shape_4.setTransform(-0.0219,-0.0189,0.65,0.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.2,-20.5,84.5,41);


(lib.elNoteName = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ALZA+QgMgEgGgGQgIgHgDgKQgEgKAAgMQAAgMAEgIQADgKAIgHQAGgIAMgDQAJgEAMAAIANABIARAFIAFAEIAAAVIgHgIQgDgCgDgEIgKgDQgFgDgHAAQgJAAgIAEQgHACgFAGQgFAFgDAIQgDAGAAAKQAAAJACAHQADAHAFAGQAEAFAIAEQAHAEAKAAQAHAAAHgDQAGgBAFgCIAHgIIAGgHIAAASIgEAFIgJAFIgLADIgNABQgMAAgJgEgAFsBCIgDgBIAAgOIAIAAQADgBAAgDIAGgGIACgMIAEgUIACgaIAAgVIBJAAIAABnIgOAAIAAhaIgvAAIAAAJIgCAfIgFAXQgBAJgEAFQgDAGgCADQgDAEgFAAIgFABgApCA+QgLgEgGgGQgHgHgFgKQgDgKAAgMQAAgMADgIQAFgKAHgHQAGgIALgDQAKgEAMAAQAMAAAKAEQAKADAHAIQAIAGAEAKQADAJAAAMQAAALgDAKQgEAKgIAHQgHAHgKAEQgKAEgMAAQgMAAgKgEgAo9gYQgIACgEAGQgFAFgDAIQgDAGAAAKQAAAJACAHQAEAHAFAGQAEAFAIAEQAHAEAKAAQAKAAAHgEQAIgCAEgHQAFgEADgIQAEgHAAgKQAAgJgEgGQgDgHgFgHQgEgEgIgEQgHgEgKAAQgKAAgHAEgAq8A+QgLgEgGgGQgIgHgDgKQgEgKAAgMQAAgMAEgIQADgKAIgHQAGgIALgDQAKgEAMAAQAMAAAKAEQAKADAIAIQAHAGADAKQAEAJABAMQgBALgEAKQgDAKgHAHQgIAHgKAEQgKAEgMAAQgMAAgKgEgAq3gYQgHACgGAGQgEAFgDAIQgDAGgBAKQABAJACAHQAEAHAEAGQAGAFAHAEQAIAEAJAAQAKAAAHgEQAIgCAFgHQAEgEADgIQAEgHAAgKQAAgJgEgGQgDgHgEgHQgFgEgIgEQgHgEgKAAQgJAAgIAEgAs2A+QgLgEgGgGQgHgHgEgKQgEgKAAgMQAAgMAEgIQAEgKAHgHQAGgIALgDQAKgEAMAAQANAAAJAEQALADAGAIQAIAGAEAKQADAJAAAMQAAALgDAKQgEAKgIAHQgGAHgLAEQgJAEgNAAQgMAAgKgEgAsxgYQgHACgFAGQgFAFgCAIQgEAGgBAKQAAAJADAHQAEAHAFAGQAFAFAHAEQAHAEAKAAQAKAAAIgEQAHgCAFgHQAFgEACgIQAEgHAAgKQAAgJgEgGQgCgHgFgHQgFgEgHgEQgIgEgKAAQgKAAgHAEgAKUBBIAAhUIhBBUIgNAAIAAhnIANAAIAABUIBBhUIAOAAIAABngAHnBBIAAhnIBGAAIAAANIg4AAIAAAfIAzAAIAAAMIgzAAIAAAiIA5AAIAAANgAFMBBIAAhaIg/AAIAABaIgOAAIAAhnIBaAAIAABngAC9BBIAAhaIglAAIAAgNIBYAAIAAANIgmAAIAABagABHBBIAAhnIBGAAIAAANIg5AAIAAAfIA0AAIAAAMIg0AAIAAAiIA7AAIAAANgAAlBBIgrgvIgRAAIAAAvIgNAAIAAhnIANAAIAAAtIAQAAIAogtIARAAIgsAyIAxA1gAiHBBIAAhnIAiAAQAVAAALAJQALAHAAASQAAAQgLAIQgLAJgVAAIgVAAIAAAkgAh6ASIAVAAQAOAAAHgGQAIgFAAgLQAAgNgIgFQgHgDgQAAIgTAAgAikBBIgMgbIgyAAIgLAbIgOAAIAqhnIAQAAIArBngAi0AZIgWgxIgTAxIApAAgAkXBBIAAhTIgmA8IgFAAIgng7IAABSIgOAAIAAhnIAQAAIAnA+IAog+IAOAAIAABngAM7AvIAQgTIgQgUIAAgOIAcAiIgcAigAMgAvIAQgTIgQgUIAAgOIAcAiIgcAigAmpAcIAdgiIAAAOIgQAUIAQATIAAAPgAnDAcIAcgiIAAAOIgQAUIAQATIAAAPgAJsgtQgFAAgFgCQgDgDgDgEQgDgDgBgIIAOAAQAAAFAEADQADACAIAAQAIAAACgCQAEgDAAgFIANAAQgBAGgCAEIgGAGQgEADgEABQgEABgGAAg");
	this.shape.setTransform(89.45,8.525);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,0,0,0)").s().p("AlkAoIAAhPILJAAIAABPg");
	this.shape_1.setTransform(87.8596,9.8209,2.4621,2.4573);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,175.7,19.7);


(lib.elNoteCode = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AJzBAIAEgHQAEgFADgIQAEgIADgLQAEgLgBgOQABgNgEgMQgDgJgEgJQgDgJgEgEIgEgHIAFgGIAIAJQAFAFADAKQAFAIAEAMQAEAMAAANQAAAOgEANQgEAMgFAIQgDAJgFAGIgIAIgAqAA+QgEgGgEgJQgFgIgEgMQgDgNAAgOIABgRIAFgQIAGgMIAGgLIAKgNIAGAGIgFAHQgDAEgEAJQgEAJgCALQgEALAAAMQAAAOAEALQACALAEAJIAHAMIAFAHIgGAGIgIgIgAImAjQgKgHAAgPIABgHQAAgEADgDQACgDAFgDQAEgEAGgBQgJgBgFgGQgDgGAAgJIABgLQACgFAEgEIAMgGIAOgBIAPABIALAFQADADACAGQACAEAAAHQABAHgEAGQgFAHgJADQAKACAGAGQAFAGAAAJQAAAIgDAGQAAAFgGAFIgLAGQgHACgKABQgRAAgKgJgAIwgBQgGAEAAAHIABAKIAFAHQADACAFABQAEABAFAAQAOAAAEgEQAHgHAAgJQAAgJgHgEQgFgEgNAAQgMAAgFAFgAIxgtQgEAFAAAHQAAAHAEAGQAFAEALAAQALAAAFgEQAFgGAAgHQAAgIgFgEQgFgEgLAAQgLAAgFAEgAGLArIgJgDIgKgHIAAgPQAEAGAHADQAJAEAKAAQANAAAFgEQAHgFgBgJQABgJgHgEQgFgDgNgBIgMAAIAAgLIAJAAQALABAGgEQAGgFAAgJQAAgIgFgFQgHgEgJAAQgKAAgGAEQgIAEgEAGIAAgPQADgFAHgDQAJgDALAAQAPAAAIAHQAIAHAAAMQAAAJgEAHQgEAGgJADQAKACAGAGQAGAFAAALQAAAGgDAFQgCAHgFADQgDAEgIACQgIACgIABIgLgBgAEmAjQgKgHAAgPIACgHQgBgEADgDQADgDAEgDQAEgEAGgBQgJgBgEgGQgEgGAAgJIABgLQADgFADgEQAFgDAGgDIAPgBIAPABIALAFQADADACAGQADAEAAAHQgBAHgEAGQgEAHgJADQAKACAGAGQAFAGAAAJQAAAIgCAGQgCAFgFAFIgKAGQgIACgKABQgRAAgKgJgAEwgBQgGAEgBAHQABAGABAEIAFAHQAEACAFABQADABAFAAQAOAAAFgEQAGgHAAgJQAAgJgGgEQgHgEgMAAQgMAAgFAFgAExgtQgFAFAAAHQAAAHAFAGQAFAEALAAQALAAAFgEQAFgGAAgHQAAgIgFgEQgFgEgLAAQgLAAgFAEgAB7ApQgGgDgFgHQgGgHgDgKQgCgKAAgMQAAgPACgKQAEgKAFgGQAFgGAHgEQAIgCAHAAQAIAAAIADQAHADAGAIQAEAGADAJQACAKAAAOQAAANgCALQgEAKgFAHQgFAGgIACQgFACgJABQgJgBgHgCgACBguQgFABgDAFQgDAEgDAIIAAAUIAAASQADAIAEAEIAHAIIAKABQAGAAAFgBIAIgGQADgFABgJQADgHAAgLQAAgLgDgJIgEgMQgEgFgFgBQgFgDgFAAQgFAAgFADgAgcApQgHgDgFgHQgGgHgCgKQgDgKAAgMQAAgPADgKQAEgKAEgGQAFgGAIgEQAHgCAIAAQAIAAAGADQAHADAGAIQAEAGADAJQACAKABAOQgBANgCALQgDAKgFAHQgGAGgHACQgFACgIABQgKgBgGgCgAgWguQgGABgDAFQgCAEgDAIQgCAIABAMQgBALACAHQADAIADAEQADAGAFACIAKABQAGAAAFgBIAGgGQADgFABgJQADgHAAgLQAAgLgDgJIgEgMQgEgFgEgBQgFgDgEAAQgGAAgEADgAjDArIgHgDIgMgHIAAgPQAGAGAHADQAHAEAJAAQAOgBAHgJQAIgJAAgTIAAgKQgDAKgJAGQgHAFgNAAQgHAAgGgCQgGgCgEgEQgFgFgBgEQgCgHAAgGQAAgIACgIQAEgGAFgFIAKgGQAHgCAHAAQAJAAAHADQAHADAGAIQAFAGADAJQACAJAAANQAAANgCAKQgEALgEAGQgHAGgHAEQgHADgJABIgKgBgAjJgrQgGAHAAAKQAAAJAGAHQAGAEALAAQALAAAHgGQAHgGAAgLQgDgJgGgFQgGgGgKAAQgKAAgHAGgAHKArIAAgJIAagYIAQgQQAGgHADgFIABgLQAAgJgGgFQgFgGgLAAQgIAAgHAEQgIAEgFAGIAAgPIAFgFIAIgDQADgCAFAAIAKgBQAPAAAIAIQAJAIAAANQAAAIgDAGQAAAGgGAGIgMANIgRARIgJAGIAyAAIAAANgADzArIAAgdIg3AAIAAgIIA0hCIAQAAIAAA+IAQAAIAAAMIgQAAIAAAdgADMACIAnAAIAAgwgABAArIAAhYIgXAOIAAgNIAbgRIAIAAIAABogAhzArIAlhZIg1AAIAAgOIBEAAIAAAIIgmBfgAkkArIAAgvIg/AAIAAAvIgOAAIAAhnIAOAAIAAAsIA/AAIAAgsIANAAIAABngAmbArIAAgvIg+AAIAAAvIgNAAIAAhnIANAAIAAAsIA+AAIAAgsIAOAAIAABngAoSArIAAhVIhBBVIgOAAIAAhnIAOAAIAABUIBBhUIAOAAIAABng");
	this.shape.setTransform(70.55,10.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,0,0,0)").s().p("AkeAoIAAhPII9AAIAABPg");
	this.shape_1.setTransform(70.5946,9.8209,2.4621,2.4573);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,141.2,19.7);


(lib.elNoteAdvertiser = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AB0A9IAAgTIg6AAIAAATIgLAAIAAgeIAJAAIAEgKIACgLIADgpIAzAAIAAA+IANAAIAAAegABMgNQAAANgDAKQgBALgEAKIAkAAIAAgzIgcAAgAIWAoQgCgCAAgFQAAgEACgCQACgCAGgBQAFABADACQACACAAAEQAAAFgCACQgDADgFAAQgGAAgCgDgAFoAqIAAgMIAHAAIAEgDIADgFIACgIIACgtIA1AAIAABJIgMAAIAAg+IgdAAIAAAFQAAAPgCAHIgCARIgFAKQgBAEgDACQgDACgDAAIgFABgAEmAhQgKgJAAgTQAAgJACgHQAEgIAFgDQAFgFAGgDQAGgCAJAAQAOAAAJAJQAJAJAAAQIAAAIIg5AAQABALAGAGQAHAGALAAQALAAAGgDQAHgEADgGIAAAOQgDAEgHACQgGADgLAAQgSAAgJgKgAFUAAQAAgLgFgFQgGgGgIAAQgLAAgHAGQgGAFgBALIAsAAIAAAAgACRAlQgHgFAAgMQAAgHADgDQABgEAFgCIAKgEIAMAAIATAAIAAgFQAAgFgCgDIgDgGIgGgCIgIgBQgIAAgHAEQgGAFgDAGIAAgSQADgDAGgCQAHgCAIAAIAMABQAHACADACQAEADACAFQADAGAAAHIAAAwIgMAAIAAgMQgDAGgHAEQgGADgJAAQgLAAgHgGgACcALQgFACAAAHQAAAEADAFQAEADAHAAQAHAAADgCQAEgBACgDIAEgFIADgEIAAgJIgSAAQgLAAgDADgAgXAhQgKgJAAgTQAAgJADgHQADgIAFgDQAFgFAGgDQAGgCAIAAQARAAAKAKQAJAKAAARQAAAKgDAHQgCAHgFAEQgFAFgGACQgIADgHAAQgQAAgKgKgAgOgPQgHAIAAAMQAAAOAHAHQAGAHALAAQALAAAGgHQAGgIAAgNQAAgOgGgGQgGgGgLgBQgLAAgGAHgAjQAlQgGgFAAgMQAAgHADgDQABgEAFgCIAKgEIAMAAIASAAIAAgFIgBgIIgEgGIgGgCIgHgBQgJAAgGAEQgGAFgEAGIAAgSQAEgDAGgCQAGgCAJAAIAMABQAGACAEACQAEADACAFQADAGAAAHIAAAwIgNAAIAAgMQgCAGgIAEQgGADgIAAQgLAAgIgGgAjFALQgFACAAAHQAAAEAEAFQAEADAHAAQAGAAAEgCQAEgBACgDIAEgFIACgEIAAgJIgRAAQgLAAgEADgAkwAqIAAgMIAIAAIADgDQACgBABgEIACgIIADgtIA1AAIAABJIgNAAIAAg+IgdAAIAAAFIgBAWIgDARIgFAKQgBAEgDACQgDACgDAAIgFABgAnDAhQgKgJAAgTQAAgJACgHQAEgIAFgDQAFgFAGgDQAGgCAJAAQAOAAAJAJQAJAJAAAQIAAAIIg5AAQABALAGAGQAHAGALAAQALAAAGgDQAHgEADgGIAAAOQgDAEgHACQgGADgLAAQgSAAgJgKgAmVAAQAAgLgFgFQgGgGgIAAQgLAAgHAGQgGAFgBALIAsAAIAAAAgAHHAqIAAhJIAMAAIAAAYIAQAAIAOABQAGABADACQAEADADAEIABAMIgBANQgDAEgEACQgDAFgGAAQgHACgIAAgAHTAfIAXAAIAHgCIADgGIACgHQAAgFgCgDQAAAAAAgBQAAAAAAgBQgBAAAAAAQgBgBAAAAQgDgCgDABIgZgBgADuAqIAAg+IgZAAIAAgLIA+AAIAAALIgZAAIAAA+gAg+AqIAAg3IgZAkIgGAAIgZgkIAAA3IgMAAIAAhJIAMAAIAcAmIAcgmIAMAAIAABJgAlCAqIgbgiIgNAAIAAAiIgMAAIAAhJIAMAAIAAAfIANAAIAXgfIAPAAIgbAiIAgAngAonAqIAAhmIAhAAQAWgBALAJQALAIAAARQAAARgLAIQgLAIgWAAIgUAAIAAAkgAoagEIAUAAQAPAAAHgGQAIgFAAgMQAAgMgIgGQgHgDgQAAIgTAAgAIWgPQgCgCAAgEQAAgEACgEQACgCAGAAQAFAAADACQACAEAAAEQAAAEgCACQgDACgFAAQgGAAgCgCg");
	this.shape.setTransform(59.175,10.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,0,0,0)").s().p("AjrAoIAAhPIHXAAIAABPg");
	this.shape_1.setTransform(58.1197,9.8209,2.4621,2.4573);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,116.2,19.7);


(lib.elNoteAd = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// noteAd
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AFjA3QAJgBAFgFQAEgEAAgEQgGgBgBgCQgCgCAAgFQAAgEACgDQABgCAGAAQAEAAADACIADAEQACAEAAAFQAAAFgDAEIgFAJQgEAEgDABIgIAEgADZAiQgGgEAAgNQAAgGACgEQACgDAFgDIAJgDIANAAIASAAIAAgGQAAgFgBgDIgEgFIgGgCIgHgCQgJAAgGAFQgGAEgEAGIAAgSQAEgDAGgBQAGgDAJAAIAMABQAGACAEADQAEADACAFQADAFAAAHIAAAxIgNAAIAAgNQgCAGgIAEQgGADgIABQgLAAgIgHgADkAIQgFADAAAGQAAAFAEAEQAEAEAHAAQAGAAAEgDQAEgBACgCIAEgGIACgDIAAgJIgRAAQgLAAgEACgAAjAiQgGgEAAgNQAAgGACgEQABgDAFgDIAKgDIANAAIASAAIAAgGQAAgFgBgDIgEgFIgGgCIgHgCQgJAAgGAFQgGAEgEAGIAAgSQAEgDAGgBQAGgDAJAAIAMABQAGACAEADQADADADAFQACAFAAAHIAAAxIgMAAIAAgNQgCAGgIAEQgGADgJABQgLAAgHgHgAAuAIQgFADAAAGQAAAFAEAEQADAEAIAAQAGAAAEgDQADgBADgCIAEgGIACgDIAAgJIgRAAQgLAAgEACgAg8AoIAAgNIAHAAIAEgDQABAAABgFIADgIIACgtIA0AAIAABKIgLAAIAAg+IgeAAIAAAEIgBAXIgCARIgFAKQgBAEgDABQgEADgCAAIgFABgAjQAfQgKgJAAgTQAAgKADgGQADgIAFgEQAFgEAGgDQAHgDAIAAQAPAAAJAJQAIAKAAAQIAAAHIg4AAQABAMAGAFQAGAGALABQALAAAGgEQAIgDACgHIAAAPQgCAEgIACQgGACgLABQgRgBgKgJgAihgCQAAgMgFgFQgGgGgJAAQgLAAgGAGQgGAFgBAMIAsAAIAAAAgAC0AoIAAg3IgYAkIgHAAIgYgkIAAA3IgNAAIAAhKIANAAIAcAnIAbgnIANAAIAABKgAhPAoIgbgiIgMAAIAAAiIgMAAIAAhKIAMAAIAAAgIAMAAIAYggIAPAAIgcAiIAgAogAk0AoIAAhnIAiAAQAWAAALAIQALAIAAASQAAARgLAIQgLAIgWAAIgUAAIAAAkgAkmgHIAUAAQAOAAAIgFQAHgGAAgLQAAgNgHgFQgIgDgQAAIgSAAgAE9AWIAQgTIgQgTIAAgPIAcAiIgcAigAEiAWIAQgTIgQgTIAAgPIAcAiIgcAigAlmADIAegiIAAAPIgQATIAQATIAAAPgAmAADIAcgiIAAAPIgQATIAQATIAAAPg");
	this.shape.setTransform(42.425,11.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,0,0,0)").s().p("AipAoIAAhPIFTAAIAABPg");
	this.shape_1.setTransform(41.7323,9.8209,2.4621,2.4573);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,83.5,19.7);


(lib.elLogoTextSber = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ak3BaQgSgIgOgNQgOgOgHgSQgIgSAAgTQAAgVAIgRQAHgSAOgOQAOgMASgIQAUgGAUAAQAUAAARAFQARAHAMALIADACIgeAVQgRgMgUABQgbAAgTARQgSASAAAaQAAAbASASQATASAbAAQASAAARgJIAJgGIAaAUQgNAOgSAIQgTAHgWAAQgUAAgUgHgADWBfIAAi8IBOAAQAmAAAWASQAVASAAAfQAAAegVATQgWASgmAAIgkAAIAAA2gAEAAJIAjAAQAUAAAKgJQALgJAAgRQAAgRgLgKQgKgJgUAAIgjAAgAAhBfIAAi8ICPAAIgqAfIg8AAIAAAuIBXAAIAAAfIhXAAIAAAwIBmAAIAAAggAikBfIAAi8ICiAAIgqAfIhPAAIAAAqIAxAAQAjAAARAPQASANAAAbQAAAcgTAQQgUAQgjAAgAh7A/IAqAAQAnAAAAgaQAAgNgKgHQgJgGgUAAIgqAAg");
	this.shape.setTransform(0,-0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-37.3,-9.7,74.6,19.4);


(lib.elLogoTextMegamarket = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("ANWBfIAAieIg/AAIAAgfICgAAIAAAfIg/AAIAACegAJ8BfIAAi9ICCAAIAAAfIhgAAIAAAuIBXAAIAAAeIhXAAIAAAzIBkAAIAAAfgAI5BfIhEhSIgeAAIAABSIgiAAIAAi9IAiAAIAABRIAcAAIA9hRIApAAIhIBaIBTBjgAD/BfIAAi9IA/AAQArAAAVARQAVAQAAAgIAAAIQgDAagTAPQgWAQgpAAIgeAAIAAA7gAEgAEIAgAAQAYAAAMgHQAIgFACgNIABgJQAAgRgLgIQgLgIgYAAIghAAgAC/BfIgSgtIhXAAIgRAtIgjAAIBMi9IAnAAIBOC9gABiAUIA+AAIgehNgAgWBfIAAiOIg9BkIgRAAIg+hiIAACMIghAAIAAi9IAqAAIA+BnIA+hnIAnAAIAAC9gAkEBfIgRgtIhXAAIgSAtIgjAAIBNi9IAnAAIBNC9gAlgAUIA9AAIgehNgAoNBfIAAi9ICAAAIAAAfIhfAAIAACegAq5BfIAAi9ICEAAIAAAfIhiAAIAAAuIBXAAIAAAeIhXAAIAAAzIBkAAIAAAfgAsIBfIAAiOIg9BkIgRAAIg+hiIAACMIgiAAIAAi9IArAAIA/BnIA9hnIAoAAIAAC9g");
	this.shape.setTransform(0.025,0.025);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-95,-9.4,190.1,18.9);


(lib.elLogoIcon = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhiB6IgDgCQgvgpgIg+QgGhAAogzQAqgyBAgIQBAgGAzAoIgfAYQgfgWglAAQgxAAgkAkQgjAjAAAyQAAAxAjAkIAJAHQAhAdArAAQAyAAAjgkQAkgkAAgyIAAgCIAigZQACAPAAAMQAAAbgJAaQgJAZgRAVQgpAzhAAHIgRABQg2AAgsgkgAg7ADIAAgrIA7AlIB8hcQAMAOAHARIiPBpg");
	this.shape.setTransform(0.0051,-0.0009);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-15.7,-15.8,31.5,31.6);


(lib.elLabel2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AjZEhQhPheAAjDQAAhlAYhKQAXhIAoguQAogvA2gWQA1gVA9AAQBFAAA3AYQA4AYAnAwQAmAvAUBIQAVBIAABgQAABngYBIQgXBJgpAuQgpAwg1AVQg1AVg9AAQiLgBhPhegAhpimQgdA4AABvQAAA7AHArQAHAqARAbQAQAaAaANQAaAMAlAAQBIAAAfg3QAdg3AAhwQAAg6gHgrQgIgqgQgbQgQgbgagNQgagNgkAAQhKgBgeA5g");
	this.shape.setTransform(24.925,29.35);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AhtF0Ig+gPIgvgVIgdgUIAAirQAiAaA0AQQA0ARBDAAQAfAAAUgIQAVgIANgMQANgLAFgQIAGgeQAAhZiPAAQgyAAgnAIIhIAUIAam0IGiAAIAACrIkOAAIgFBeIAjgEIAhgCQA/AAAwATQAvATAeAgQAeAgAPAqQAPArAAAzQAAA/gXAxQgVAwgnAhQgmAig0AQQg0ARg4AAQgoAAgkgHg");
	this.shape_1.setTransform(-34.75,29.675);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AOFDRQgKgJgHgNQgKgWAAgfQAAgyAcgYQAdgYAzAAQA0AAAbAYQAaAYAAAyQAAAbgHASIgEAIQgHAOgMAJQgNAMgVAGQgTAFgZAAQgyAAgcgYgAOyBhQgLALAAAaQAAAaAMAMQAMALAWAAQAWAAAMgLQAMgLAAgbQAAgagMgLQgLgMgYAAQgWAAgMAMgAKpDgIEamNIA8AAIkZGNgAw+BsIAAiAIE8AAIAACAgAKEgGQgcgYAAgzQAAgyAcgZQAdgYAzAAQA0AAAbAYQAbAZAAAyQAAAagHATQgJATgOALQgOAMgUAFQgUAGgZAAQgyAAgbgXgAKwh2QgLALAAAaQAAAZAMALQAMAMAVAAQAXAAAMgLQAMgLAAgaQAAgagMgLQgLgLgYAAQgWAAgMALgAvDg1IAAgbIhbAAIAAAbIgfAAIAAg6IAPAAQADgHADgKIAFgXIAFhOIBnAAIAAB2IATAAIAAA6gAwDiTIgJAkIAyAAIAAhYIglAAgAuIhgQgTgSAAgpQAAgoASgSQATgTAlAAQAUAAAOAFQAOAEAIAKQAJAKAEAOQAEAOAAAUQAAAVgFAPQgEAPgKAJQgJAJgOAEQgNAEgSAAQgkAAgTgSgAtti/QgJALAAAZQAAAOADAKQADAIAFAGQAEAFAHACQAHACAJAAQAIAAAHgCQAHgCAFgGQAEgFACgJQACgJAAgOQAAgNgCgJQgCgJgFgGQgFgFgHgDQgHgCgJAAQgSAAgJALg");
	this.shape_2.setTransform(-0.025,26.575);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAVAsIAAgbIgPAAIgDAAIgDAAIgSAbIgSAAIAVgfQgJgDgEgHQgEgFAAgLQAAgPAKgHQAKgIASAAIAfAAIAABXgAgLgZQgFAEAAAJQAAAIAFAEQAFACALAAIAQAAIAAgfIgQAAQgKAAgGAEg");
	this.shape_3.setTransform(28.725,-25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAYAsIAAhCIguBCIgSAAIAAhXIAQAAIAABAIAvhAIARAAIAABXg");
	this.shape_4.setTransform(19.45,-25);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAYAsIAAgmIgvAAIAAAmIgQAAIAAhXIAQAAIAAAkIAvAAIAAgkIAQAAIAABXg");
	this.shape_5.setTransform(9.075,-25);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAcAsIgIgVIgoAAIgIAVIgQAAIAkhXIARAAIAkBXgAAOAJIgOgjIgOAjIAcAAg");
	this.shape_6.setTransform(-0.6,-25);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgHAsIAAhJIgdAAIAAgOIBJAAIAAAOIgdAAIAABJg");
	this.shape_7.setTransform(-9.075,-25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAYAsIAAhCIguBCIgRAAIAAhXIAPAAIAABAIAwhAIARAAIAABXg");
	this.shape_8.setTransform(-18.2,-25);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAXAsIAAhJIguAAIAABJIgPAAIAAhXIBNAAIAABXg");
	this.shape_9.setTransform(-28.425,-25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAeAsIAAhXIAQAAIAABXgAgtAsIAAhXIAQAAIAAAbIAKAAQAUAAAKAIQAJAHAAAOQAAAQgKAHQgKAIgSAAgAgdAeIAMAAQALgBAFgEQAFgDAAgJQAAgJgEgDQgFgCgMgBIgMAAg");
	this.shape_10.setTransform(74.375,-41.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgHAsIAAhJIgdAAIAAgOIBJAAIAAAOIgdAAIAABJg");
	this.shape_11.setTransform(64.775,-41.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAVAsIgggmIgNAAIAAAmIgQAAIAAhXIAQAAIAAAlIANAAIAbglIATAAIghApIAnAug");
	this.shape_12.setTransform(56.7,-41.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgQAsIgFgBIAAgRQAAAAABABQAAAAABABQAAAAABAAQAAAAABAAIAFABIAFgBQACAAABgDIgmhEIASAAIAbAyIAYgyIAQAAIggBEIgGAKQgCADgDACQgCADgDABIgGABg");
	this.shape_13.setTransform(47,-41.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAeA0IAAgQIg8AAIAAAQIgOAAIAAgfIAJAAIADgKIADgLIACgPIABgSIABgSIA9AAIAABIIAKAAIAAAfgAgMghQAAAigHAUIAmAAIAAg6IgfAAg");
	this.shape_14.setTransform(37.65,-40.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgSAqQgJgDgGgGQgGgFgEgJQgDgIAAgLQAAgJADgJQAEgIAGgGQAGgGAJgDQAIgDAKgBQALAAAIAEQAJACAGAHQAHAFADAJQADAIAAAKQAAAKgDAIQgDAIgGAHQgHAFgIAEQgJAEgLgBQgJAAgJgDgAgMgcQgFACgEAFQgEADgCAHQgCAFAAAGQAAAGABAGQACAGAEAEQAEAEAGACQAGADAGAAQAHAAAGgDQAGgCADgDQAEgFADgFQACgGAAgHQAAgGgCgFQgCgGgEgEQgEgEgGgDQgFgCgIAAQgGAAgGACg");
	this.shape_15.setTransform(27.775,-41.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgiAsIAAhXIAeAAQAUAAAJAHQAKAIAAAPQAAAOgKAIQgLAHgSAAIgOAAIAAAcgAgSACIAPAAQAKAAAFgDQAGgEAAgIQAAgJgFgEQgFgDgLAAIgPAAg");
	this.shape_16.setTransform(18.5,-41.15);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAXAsIAAhJIguAAIAABJIgPAAIAAhXIBNAAIAABXg");
	this.shape_17.setTransform(8.875,-41.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AAcAsIgIgVIgoAAIgIAVIgQAAIAjhXIARAAIAlBXgAAOAIIgOgjIgOAjIAcAAg");
	this.shape_18.setTransform(-4.05,-41.15);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAYAsIAAgmIgvAAIAAAmIgQAAIAAhXIAQAAIAAAjIAvAAIAAgjIAQAAIAABXg");
	this.shape_19.setTransform(-13.775,-41.15);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAZAsIAAhCIgvBCIgRAAIAAhXIAPAAIAABBIAwhBIARAAIAABXg");
	this.shape_20.setTransform(-27.3,-41.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAUAsIgfgmIgNAAIAAAmIgQAAIAAhXIAQAAIAAAlIANAAIAcglIATAAIgiApIAnAug");
	this.shape_21.setTransform(-36.7,-41.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AAeA0IAAgQIg8AAIAAAQIgPAAIAAgfIAKAAIADgKIADgLIACgPIABgSIAAgSIA9AAIAABIIAKAAIAAAfgAgLghQgBAigHAUIAmAAIAAg6IgeAAg");
	this.shape_22.setTransform(-46.75,-40.325);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAYAsIAAhCIgvBCIgRAAIAAhXIAQAAIAABBIAvhBIARAAIAABXg");
	this.shape_23.setTransform(-56.6,-41.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAUAsIgfgmIgNAAIAAAmIgQAAIAAhXIAQAAIAAAlIANAAIAcglIATAAIgiApIAnAug");
	this.shape_24.setTransform(-65.95,-41.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgKAqQgJgDgGgGQgHgFgDgJQgEgIAAgLQAAgJAEgJQADgIAHgGQAGgGAJgDQAJgDAKgBQAKABAHACQAIACAEADIAAAXIgFgGIgHgGIgIgDIgJgBQgIAAgEACQgGACgEAFQgEAEgCAFQgDAGAAAGQAAAGACAGQACAGAEAEQAEAEAGACQAFADAHAAQAGAAAFgBQAFgCAEgCIAHgFIAFgGIAAATIgFAFIgHADIgJACIgLABQgKABgIgEg");
	this.shape_25.setTransform(-75.625,-41.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.7,-50.5,217.4,154.9);


(lib.elDisText2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.dis2();
	this.instance.setTransform(115,179.25,0.5,0.5,180);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,0.8,230,178.5);


(lib.BORDER = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_19 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(19).call(this.frame_19).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4D007D").s().p("EicPAAKIAAgTME4fAAAIAAATg");
	this.shape.setTransform(999,-1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1).to({y:-0.95},0).wait(1).to({y:-0.9},0).wait(1).to({y:-0.85},0).wait(1).to({y:-0.8},0).wait(1).to({y:-0.75},0).wait(1).to({y:-0.7},0).wait(1).to({y:-0.65},0).wait(1).to({y:-0.6},0).wait(1).to({y:-0.55},0).wait(1).to({y:-0.45},0).wait(1).to({y:-0.4},0).wait(1).to({y:-0.35},0).wait(1).to({y:-0.3},0).wait(1).to({y:-0.25},0).wait(1).to({y:-0.2},0).wait(1).to({y:-0.15},0).wait(1).to({y:-0.1},0).wait(1).to({y:-0.05},0).wait(1).to({y:0},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-2,2000,3);


(lib.elBg = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// img
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#A263DC").s().p("Eg+fA+gMAAAh8/MB8/AAAMAAAB8/g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-400,-400,800,800);


(lib.elLogoArea = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A06G6IAAtzMAp1AAAIAANzg");
	this.shape.setTransform(0,-0.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("A7TFcIAAq3MA2nAAAIAAK3g");

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF00").s().p("AyJG0IAAtnMAkTAAAIAANng");
	this.shape_2.setTransform(-0.2,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[]},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-174.8,-46.2,349.6,90.4);


(lib.elBtnArea = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#252525").s().p("AnzH0IAAvnIPnAAIAAPng");
	this.shape.setTransform(-0.2,0);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(3).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-50.2,-50,100,100);


(lib.elSloganOneStroke = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// text
	this.instance = new lib.elSloganTextProfit("synched",0);
	this.instance.setTransform(28.8,-2.35,0.8091,0.8091,0,0,0,3.1,-1.4);

	this.instance_1 = new lib.elSloganTextMega("synched",0);
	this.instance_1.setTransform(-40.15,2.8,0.8091,0.8091,0,0,0,-3,1.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#F3911D","#ECF012"],[0,1],-7.5,27.4,1.6,-23.1).s().p("Ar+C1QgIgQALgOIBIhdQAMgQgBgUQAAgVgOgOIhNhYQgNgOAIgQQAHgQARgBIVigvQARAAAOAHQAPAGALANIBRBjQAPATABAYQABAYgOASIhLBpQgJANgOAIQgPAIgQABI1iAuIgBAAQgRAAgIgPg");
	this.shape.setTransform(-0.0123,-0.0009);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// area
	this.elLogoArea = new lib.elLogoArea("synched",2,false);
	this.elLogoArea.name = "elLogoArea";
	this.elLogoArea.setTransform(-0.05,0,0.8091,0.8091);
	this.elLogoArea.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.elLogoArea).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-94.2,-35.2,188,70.5);


(lib.BLOCK_START_240x400 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// plate3
	this.instance = new lib.elPlate3("synched",0);
	this.instance.setTransform(188.75,300.6,0.8,0.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({y:79.2,alpha:1},8,cjs.Ease.quadOut).to({startPosition:0},19).to({x:284.75,y:53.2},7,cjs.Ease.quadInOut).to({startPosition:0},15).to({regX:0.4,regY:-0.1,scaleX:0.6685,scaleY:0.6685,rotation:-29.813,x:167.75,y:-288.5},11,cjs.Ease.quadInOut).to({startPosition:0},101,cjs.Ease.quadInOut).wait(1).to({regX:0,regY:0,rotation:-28.8163,x:166.5587,y:-275.3837},0).wait(1).to({rotation:-26.2451,x:164.0015,y:-242.0627},0).wait(1).to({rotation:-21.8027,x:159.5844,y:-184.4952},0).wait(1).to({rotation:-15.3659,x:153.1859,y:-101.0828},0).wait(1).to({scaleX:0.6686,scaleY:0.6686,rotation:-7.3314,x:145.203,y:3.0294},0).wait(1).to({rotation:1.169,x:136.7618,y:113.1763},0).wait(1).to({rotation:8.7721,x:129.216,y:211.6947},0).wait(1).to({scaleX:0.6687,scaleY:0.6687,rotation:14.6713,x:123.3642,y:288.1343},0).wait(1).to({rotation:18.7288,x:119.3408,y:340.7091},0).wait(1).to({regX:0.5,regY:-0.1,rotation:21.1403,x:117.2,y:371.95},0).to({_off:true},1).wait(2));

	// promoText1
	this.instance_1 = new lib.textPromo1("synched",0);
	this.instance_1.setTransform(1.2,300.6,0.8,0.8);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({y:10.7,alpha:1},9,cjs.Ease.quadOut).to({startPosition:0},17).to({x:194.65,y:-10.4,alpha:0},7,cjs.Ease.quadInOut).to({_off:true},1).wait(139));

	// plate4
	this.instance_2 = new lib.elPlate4("synched",0);
	this.instance_2.setTransform(19.9,300.6,0.8,0.8);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(5).to({_off:false},0).to({y:101.7,alpha:1},9,cjs.Ease.quadOut).to({startPosition:0},17).to({x:210.9,y:79.7},7,cjs.Ease.quadInOut).to({startPosition:0},15).to({regX:0.1,regY:0.1,scaleX:0.6684,scaleY:0.6684,rotation:-23.8148,x:90.25,y:-274.8},11,cjs.Ease.quadInOut).to({startPosition:0},101,cjs.Ease.quadInOut).wait(1).to({regX:0,regY:0,rotation:-23.0489,x:89.415,y:-262.4484},0).wait(1).to({scaleX:0.6685,scaleY:0.6685,rotation:-21.0731,x:87.519,y:-230.5837},0).wait(1).to({rotation:-17.6595,x:84.2436,y:-175.5314},0).wait(1).to({rotation:-12.7132,x:79.4983,y:-95.7616},0).wait(1).to({scaleX:0.6686,scaleY:0.6686,rotation:-6.5392,x:73.5763,y:3.8069},0).wait(1).to({rotation:-0.0073,x:67.3122,y:109.1495},0).wait(1).to({scaleX:0.6687,scaleY:0.6687,rotation:5.8352,x:61.7105,y:203.373},0).wait(1).to({rotation:10.3683,x:57.3647,y:276.4813},0).wait(1).to({rotation:13.4863,x:54.3761,y:326.7652},0).wait(1).to({regX:0.1,regY:0.1,rotation:15.3393,x:52.65,y:356.7},0).to({_off:true},1).wait(2));

	// promoText2
	this.instance_3 = new lib.textPromo2("synched",0);
	this.instance_3.setTransform(-69.85,18.05,0.8,0.8);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(31).to({_off:false},0).to({x:1.3,y:-1.7,alpha:1},7,cjs.Ease.quadInOut).to({startPosition:0},15).to({y:-131.85,alpha:0.1719},5,cjs.Ease.quadIn).to({_off:true},1).wait(119));

	// plate5
	this.instance_4 = new lib.elPlate5("synched",0);
	this.instance_4.setTransform(-76.3,300.6,0.8,0.8);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(6).to({_off:false},0).to({y:129.2,alpha:1},8,cjs.Ease.quadOut).to({startPosition:0},17).to({x:-4.35,y:105.2},7,cjs.Ease.quadInOut).to({startPosition:0},15).to({regX:0.6,regY:-0.2,scaleX:0.6684,scaleY:0.6684,rotation:-18.8122,x:12.5,y:-262.75},11,cjs.Ease.quadInOut).to({startPosition:0},101,cjs.Ease.quadInOut).wait(1).to({regX:20,regY:0,rotation:-18.2387,x:24.35,y:-254.65},0).wait(1).to({scaleX:0.6685,scaleY:0.6685,rotation:-16.7593,x:23.2,y:-223.4},0).wait(1).to({rotation:-14.2033,x:21.2,y:-169.5},0).wait(1).to({rotation:-10.4997,x:18.3,y:-91.35},0).wait(1).to({scaleX:0.6686,scaleY:0.6686,rotation:-5.8769,x:14.55,y:6.2},0).wait(1).to({rotation:-0.9861,x:10.55,y:109.4},0).wait(1).to({scaleX:0.6687,scaleY:0.6687,rotation:3.3885,x:6.85,y:201.75},0).wait(1).to({rotation:6.7828,x:3.95,y:273.4},0).wait(1).to({rotation:9.1173,x:1.9,y:322.65},0).wait(1).to({regX:0.5,regY:-0.1,rotation:10.5048,x:-12.1,y:349.5},0).to({_off:true},1).wait(2));

	// plate6
	this.instance_5 = new lib.elPlate6("synched",0);
	this.instance_5.setTransform(-227.65,300.6,0.8,0.8);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(7).to({_off:false},0).to({y:153,alpha:1},7,cjs.Ease.quadOut).to({startPosition:0},17).to({x:-98.65,y:130},7,cjs.Ease.quadInOut).to({startPosition:0},15).to({regX:-0.1,regY:-0.1,scaleX:0.6684,scaleY:0.6684,rotation:-15.8117,x:-72.7,y:-251.9},11,cjs.Ease.quadInOut).to({startPosition:0},101,cjs.Ease.quadInOut).wait(1).to({regX:0,regY:0,rotation:-15.3537,x:-73.1112,y:-240.1261},0).wait(1).to({rotation:-14.1721,x:-74.3011,y:-209.881},0).wait(1).to({scaleX:0.6685,scaleY:0.6685,rotation:-12.1305,x:-76.357,y:-157.6269},0).wait(1).to({rotation:-9.1724,x:-79.336,y:-81.9118},0).wait(1).to({rotation:-5.4801,x:-83.0545,y:12.5952},0).wait(1).to({scaleX:0.6686,scaleY:0.6686,rotation:-1.5737,x:-86.9889,y:112.582},0).wait(1).to({rotation:1.9203,x:-90.5081,y:202.0143},0).wait(1).to({scaleX:0.6687,scaleY:0.6687,rotation:4.6314,x:-93.2387,y:271.4046},0).wait(1).to({rotation:6.496,x:-95.1169,y:319.1309},0).wait(1).to({regX:-0.1,regY:-0.1,rotation:7.6042,x:-96.25,y:347.45},0).to({_off:true},1).wait(2));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-331.6,-440.2,720.4000000000001,973.8);


(lib.BLOCK_SLOGAN1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.elSloganChoice = new lib.elSloganOneStroke("single",0);
	this.elSloganChoice.name = "elSloganChoice";
	this.elSloganChoice.setTransform(-131.95,4.6,0.86,0.86);
	this.elSloganChoice.alpha = 0.0781;

	this.timeline.addTween(cjs.Tween.get(this.elSloganChoice).to({scaleX:1,scaleY:1,x:0.05,y:0,alpha:1},11,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-212.9,-35.2,306.8,70.5);


(lib.BLOCK_PICTURE = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// products
	this.instance = new lib.elProduct("synched",0);
	this.instance.setTransform(-0.05,-0.05,0.33,0.33);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1,scaleY:1,x:0,y:0,alpha:1},10,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-125,-125,250,250);


(lib.BLOCK_DISCOUNT = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// discount
	this.instance = new lib.elDiscount("synched",0);
	this.instance.setTransform(0.9,0,0.3,0.3,0,0,0,0.4,-0.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({regY:-0.2,scaleX:0.9999,scaleY:1,x:3,y:-0.05,alpha:1},10,cjs.Ease.backOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-42.4,-21.8,90.4,43.8);


(lib.elNote2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// note
	this.instance = new lib.elNoteCode("synched",0);
	this.instance.setTransform(148.95,-4.15,0.5992,0.5992,0,0,0,73.2,12.8);

	this.instance_1 = new lib.elNoteName("synched",0);
	this.instance_1.setTransform(53.6,-4.15,0.5992,0.5992,0,0,0,89.5,12.8);

	this.instance_2 = new lib.elNoteAdvertiser("synched",0);
	this.instance_2.setTransform(86.05,-19.4,0.5992,0.5992,0,0,0,60.6,6.9);

	this.instance_3 = new lib.elNoteAd("synched",0);
	this.instance_3.setTransform(26.15,-19.4,0.5992,0.5992,0,0,0,43.6,6.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,-23.5,189.70000000000002,23.5);


(lib.elCensor = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// censor
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0)").s().p("AgDAkIAAggIggAAIAAgHIAgAAIAAggIAHAAIAAAgIAgAAIAAAHIggAAIAAAgg");
	this.shape.setTransform(8.325,0.175);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0)").s().p("AgQA7QgIgCgGgEQgGgEgDgHQgDgGAAgIQAAgMAHgIQAGgIAOgCQgKgCgGgHQgHgHAAgMQAAgHADgFQACgGAFgEQAFgEAHgCQAHgCAJAAQASAAAKAIQAJAIAAANQAAAMgGAHQgHAHgKADQAOACAHAGQAIAIAAANQAAAIgDAGQgDAHgGAEQgFAFgIACQgIACgKAAQgIAAgIgCgAgOADQgHABgEAEQgFADgCAFQgCAFAAAFQAAANAKAHQAJAHAPAAQASAAAIgHQAJgIAAgMQAAgLgJgHQgJgHgRAAQgIAAgGACgAgWguQgIAGAAALQAAAFACAFQADAEAEADQAEAEAFABQAGACAGAAQAOAAAIgHQAIgHAAgKQAAgLgIgGQgHgGgPAAQgOAAgIAGg");
	this.shape_1.setTransform(0.125,0.075);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("rgba(255,255,255,0)").s().p("AANA8IAAhtIghAVIAAgIIAjgXIAGAAIAAB3g");
	this.shape_2.setTransform(-7.4,0.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("rgba(255,255,255,0)").s().p("AhVBUIAAACQgiglAAgxQAAgxAigkQAkgiAxAAQAyAAAkAiQAiAkAAAxQAAAygiAiQgkAkgyAAQgxAAgkgkgAhNhNQgiAgAAAtQAAAuAiAhQAgAfAtAAQAuAAAhgfQAhghAAguIAAgFQgCgsgfgcQghghguAAQgtAAggAhg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// area
	this.instance = new lib.elBtnArea("single",3);
	this.instance.setTransform(0.1,0,0.35,0.35,0,0,0,0.1,0);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35,35);


(lib.BLOCK_NOTE_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// elNoteChoice
	this.instance = new lib.elNote2("single",0);
	this.instance.setTransform(5,-5);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},7,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(5.1,-28.5,189.70000000000002,23.5);


(lib.BLOCK_CENSOR = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// elCensor
	this.instance = new lib.elCensor("synched",0,false);
	this.instance.setTransform(0.4,0.1,1,1,0,0,0,0.4,0.1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},7,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.5,-17.5,35,35);


(lib.elLogoStroke = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.instance = new lib.elLogoTextMegamarket("single",0);
	this.instance.setTransform(19.85,15.75);

	this.instance_1 = new lib.elLogoTextSber("single",0);
	this.instance_1.setTransform(-38.95,-9.35);

	this.instance_2 = new lib.elLogoIcon("single",0);
	this.instance_2.setTransform(-99.2,-9.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).to({state:[]},1).wait(1));

	// area
	this.elLogoArea = new lib.elLogoArea("synched",0,false);
	this.elLogoArea.name = "elLogoArea";
	this.elLogoArea.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.elLogoArea).to({_off:true},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-174.8,-44.2,349.6,88.4);


(lib.BLOCK_LOGO_240x400 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// logo
	this.elLogoChoice = new lib.elLogoStroke("single",0);
	this.elLogoChoice.name = "elLogoChoice";
	this.elLogoChoice.setTransform(0.1,-240.05,0.8887,0.8887,0,0,0,0.1,-0.1);
	this.elLogoChoice.alpha = 0;
	this.elLogoChoice._off = true;

	this.timeline.addTween(cjs.Tween.get(this.elLogoChoice).wait(1).to({_off:false},0).to({y:-160.05,alpha:1},13,cjs.Ease.quadOut).to({startPosition:0},150).to({y:-100.65},7,cjs.Ease.quadIn).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-119,-279.2,238.1,279.2);


(lib.BLOCK_LABEL_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// area
	this.elLabel = new lib.elLabel2("single",0);
	this.elLabel.name = "elLabel";
	this.elLabel.setTransform(0,0,0.3,0.3);
	this.elLabel.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.elLabel).to({scaleX:1,scaleY:1,alpha:1},10,cjs.Ease.quadOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-108.7,-50.5,217.4,154.9);


(lib.BLOCK_DIS_240x400 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// dis
	this.distext = new lib.elDisText2("synched",0);
	this.distext.name = "distext";
	this.distext.setTransform(0,82,1,1,180,0,0,0,113);

	this.timeline.addTween(cjs.Tween.get(this.distext).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-115,15.8,230,178.5);


(lib.BLOCK_BG_240x400 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_9 = function() {
		var _this = this;
		_this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(9).call(this.frame_9).wait(1));

	// bg
	this.instance = new lib.elBg("synched",0);
	this.instance.setTransform(0.05,0,0.3,0.5,0,0,0,0.1,0);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},9,cjs.Ease.quadInOut).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120,-200,240,400);


(lib._07_CONTAINER_240x400 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// timeline functions:
	this.frame_101 = function() {
		var _this = this;
		repeat ++; 
		if(repeat > maxrepeat) _this.stop();
	}
	this.frame_254 = function() {
		var _this = this;
		if(repeat > 1) _this.bg.gotoAndStop(9);
		_this.gotoAndPlay(1);
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(101).call(this.frame_101).wait(153).call(this.frame_254).wait(1));

	// OVERBG
	this.overbg = new lib.BLOCK_BG_240x400("synched",0,false);
	this.overbg.name = "overbg";
	this.overbg._off = true;

	this.timeline.addTween(cjs.Tween.get(this.overbg).wait(245).to({_off:false},0).wait(10));

	// LOGO
	this.logo = new lib.BLOCK_LOGO_240x400("synched",0,false);
	this.logo.name = "logo";

	this.timeline.addTween(cjs.Tween.get(this.logo).wait(255));

	// FINISH
	this.instance = new lib.BLOCK_START_240x400("synched",165,false);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(165).to({_off:false},0).to({_off:true},11).wait(79));

	// DIS
	this.dis = new lib.BLOCK_DIS_240x400("synched",0,false);
	this.dis.name = "dis";
	this.dis._off = true;

	this.timeline.addTween(cjs.Tween.get(this.dis).wait(171).to({_off:false},0).wait(84));

	// CENSOR
	this.censor = new lib.BLOCK_CENSOR("synched",0,false);
	this.censor.name = "censor";
	this.censor.setTransform(101.8,182.45);

	this.timeline.addTween(cjs.Tween.get(this.censor).to({_off:true},171).wait(84));

	// NOTE
	this.note = new lib.BLOCK_NOTE_2("synched",0,false);
	this.note.name = "note";
	this.note.setTransform(-115,195,1,1,0,0,0,5,-5);

	this.timeline.addTween(cjs.Tween.get(this.note).to({_off:true},171).wait(84));

	// DISCOUNT
	this.discount = new lib.BLOCK_DISCOUNT("synched",0,false);
	this.discount.name = "discount";
	this.discount.setTransform(63.85,-75.35,0.9998,0.9998,-3.8129,0,0,0.2,-0.1);
	this.discount._off = true;

	this.timeline.addTween(cjs.Tween.get(this.discount).wait(63).to({_off:false},0).to({_off:true},105).wait(87));

	// SLOGAN
	this.slogan = new lib.BLOCK_SLOGAN1("synched",0,false);
	this.slogan.name = "slogan";
	this.slogan.setTransform(-0.1,-100.2,1,1,0,0,0,-0.1,-0.1);

	this.instance_1 = new lib.BLOCK_SLOGAN1("synched",0,false);
	this.instance_1.setTransform(-2.8,-32.25,1.07,1.07,0,0,0,-0.1,-0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.slogan}]},73).to({state:[]},95).to({state:[{t:this.instance_1}]},12).wait(75));

	// LABEL
	this.label = new lib.BLOCK_LABEL_2("synched",0,false);
	this.label.name = "label";
	this.label.setTransform(-0.1,-27.6,0.8871,0.8867,0,0,0,-0.1,-0.1);
	this.label._off = true;

	this.timeline.addTween(cjs.Tween.get(this.label).wait(60).to({_off:false},0).to({_off:true},110).wait(85));

	// PRODUCT
	this.product = new lib.BLOCK_PICTURE("synched",0,false);
	this.product.name = "product";
	this.product.setTransform(0.15,107.55,0.86,0.86,0,0,0,0.2,0.5);
	this.product._off = true;

	this.timeline.addTween(cjs.Tween.get(this.product).wait(57).to({_off:false},0).to({_off:true},114).wait(84));

	// START
	this.instance_2 = new lib.BLOCK_START_240x400("synched",0,false);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({_off:true},165).wait(90));

	// BG
	this.bg = new lib.BLOCK_BG_240x400();
	this.bg.name = "bg";

	this.timeline.addTween(cjs.Tween.get(this.bg).wait(255));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-331.5,-440.1,720.2,962.2);


// stage content:
(lib._FIRSTDATA_240x400 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var main = this; main.stop();
		
		main.BORDER_L.x = 0; 	main.BORDER_L.y = 0; 	main.BORDER_R.x = lib.properties["width"]-1; 	main.BORDER_R.y = lib.properties["height"]-1;
		main.BORDER_T.x = 0; 	main.BORDER_T.y = 0; 	main.BORDER_B.x = lib.properties["width"]-1; 	main.BORDER_B.y = lib.properties["height"]-1;
		
		var simplifier 	= false;
		var c120x600 	= false; 
		var c160x600 	= false; 
		var c240x600 	= false; 
		var c300x600 	= false; 
		var c320x480 	= false; 
		var c300x500 	= false; 
		var c240x400 	= true; 
		var c200x200 	= false; 
		var c250x250 	= false; 
		var c300x300 	= false; 
		var c300x250 	= false; 
		var c336x280 	= false; 
		var c480x320 	= false; 
		var c580x400 	= false; 
		var c970x250 	= false; 
		var c1000x120 	= false; 
		var c970x90 	= false; 
		var c728x90 	= false; 
		var c468x60 	= false; 
		var c320x100 	= false; 
		var c320x50 	= false; 
		var c400x90 	= false; 
		var c600x250 	= false; 
		
		repeat = 0;
		maxrepeat = 999;
		
		///////////////////////////////////////
		
		
		////////////////////////////////////
		
		////////////  DATA SET  ////////////
		if(simplifier == true) root.dataSet = 1686047309265;
		
		////////////  01_c120x600  ////////////
		if(c120x600 == true){ 
			main.c120x600.product.x = 0;
			main.c120x600.product.y = 8;
			main.c120x600.product.scale = 0.53;
			main.c120x600.product.rotation = 0;
			main.c120x600.label.x = -0.1;
			main.c120x600.label.y = 131.45;
			main.c120x600.label.scale = 0.5001;
			main.c120x600.label.rotation = 0;
			main.c120x600.slogan.x = -0.1;
			main.c120x600.slogan.y = -120.45;
			main.c120x600.slogan.scale = 0.97;
			main.c120x600.slogan.rotation = 0;
			main.c120x600.discount.x = 0.35;
			main.c120x600.discount.y = -57.2;
			main.c120x600.discount.scale = 0.8998;
			main.c120x600.discount.rotation = -3.7532;
		}
		
		////////////  02_c160x600  ////////////
		if(c160x600 == true){ 
			main.c160x600.product.x = 0.4;
			main.c160x600.product.y = -1.05;
			main.c160x600.product.scale = 0.69;
			main.c160x600.product.rotation = 0;
			main.c160x600.label.x = -0.05;
			main.c160x600.label.y = 128.3;
			main.c160x600.label.scale = 0.6601;
			main.c160x600.label.rotation = 0;
			main.c160x600.slogan.x = -0.1;
			main.c160x600.slogan.y = -123.3;
			main.c160x600.slogan.scale = 1.1741;
			main.c160x600.slogan.rotation = 0;
			main.c160x600.discount.x = 18.5;
			main.c160x600.discount.y = -81.05;
			main.c160x600.discount.scale = 1.1937;
			main.c160x600.discount.rotation = -3.7528;
		}
		
		////////////  03_c240x600  ////////////
		if(c240x600 == true){ 
			main.c240x600.product.x = 0.3;
			main.c240x600.product.y = 1;
			main.c240x600.product.scale = 0.97;
			main.c240x600.product.rotation = 0;
			main.c240x600.label.x = -0.2;
			main.c240x600.label.y = 154.3;
			main.c240x600.label.scale = 1.0002;
			main.c240x600.label.rotation = 0;
			main.c240x600.slogan.x = -0.15;
			main.c240x600.slogan.y = -137.8;
			main.c240x600.slogan.scale = 1.27;
			main.c240x600.slogan.rotation = 0;
			main.c240x600.discount.x = 63.85;
			main.c240x600.discount.y = -127.1;
			main.c240x600.discount.scale = 0.9998;
			main.c240x600.discount.rotation = -3.8129;
		}
		
		////////////  04_c300x600  ////////////
		if(c300x600 == true){ 
			main.c300x600.product.x = 6;
			main.c300x600.product.y = -8;
			main.c300x600.product.scale = 1.21;
			main.c300x600.product.rotation = 0;
			main.c300x600.label.x = 0;
			main.c300x600.label.y = 162;
			main.c300x600.label.scale = 1.2;
			main.c300x600.label.rotation = 0;
			main.c300x600.slogan.x = -0.15;
			main.c300x600.slogan.y = -157.55;
			main.c300x600.slogan.scale = 1.5209;
			main.c300x600.slogan.rotation = 0;
			main.c300x600.discount.x = 86.2;
			main.c300x600.discount.y = -123.85;
			main.c300x600.discount.scale = 1.2497;
			main.c300x600.discount.rotation = -3.8128;
		}
		
		////////////  05_c320x480  ////////////
		if(c320x480 == true){ 
			main.c320x480.product.x = 2;
			main.c320x480.product.y = 13;
			main.c320x480.product.scale = 0.95;
			main.c320x480.product.rotation = 0;
			main.c320x480.label.x = 0;
			main.c320x480.label.y = 139;
			main.c320x480.label.scale = 0.94;
			main.c320x480.label.rotation = 0;
			main.c320x480.slogan.x = -0.1;
			main.c320x480.slogan.y = -109;
			main.c320x480.slogan.scale = 1.25;
			main.c320x480.slogan.rotation = 0;
			main.c320x480.discount.x = 86.2;
			main.c320x480.discount.y = -74.55;
			main.c320x480.discount.scale = 1.2497;
			main.c320x480.discount.rotation = -3.8128;
		}
		
		////////////  06_c300x500  ////////////
		if(c300x500 == true){ 
			main.c300x500.product.x = 0;
			main.c300x500.product.y = 5;
			main.c300x500.product.scale = 1.07;
			main.c300x500.product.rotation = 0;
			main.c300x500.label.x = -6;
			main.c300x500.label.y = 144.000244140625;
			main.c300x500.label.scale = 0.98;
			main.c300x500.label.rotation = 0;
			main.c300x500.slogan.x = -0.1;
			main.c300x500.slogan.y = -123.45;
			main.c300x500.slogan.scale = 1.25;
			main.c300x500.slogan.rotation = 0;
			main.c300x500.discount.x = 86.2;
			main.c300x500.discount.y = -89.65;
			main.c300x500.discount.scale = 1.2497;
			main.c300x500.discount.rotation = -3.8128;
		}
		
		////////////  07_c240x400  ////////////
		if(c240x400 == true){ 
			main.c240x400.product.x = 0;
			main.c240x400.product.y = 3;
			main.c240x400.product.scale = 0.84;
			main.c240x400.product.rotation = 0;
			main.c240x400.label.x = 0;
			main.c240x400.label.y = 110;
			main.c240x400.label.scale = 0.81;
			main.c240x400.label.rotation = 0;
			main.c240x400.slogan.x = -0.1;
			main.c240x400.slogan.y = -100.2;
			main.c240x400.slogan.scale = 1;
			main.c240x400.slogan.rotation = 0;
			main.c240x400.discount.x = 63.85;
			main.c240x400.discount.y = -75.35;
			main.c240x400.discount.scale = 0.9998;
			main.c240x400.discount.rotation = -3.8129;
		}
		
		////////////  08_c200x200  ////////////
		if(c200x200 == true){ 
			main.c200x200.product.x = 43;
			main.c200x200.product.y = 38;
			main.c200x200.product.scale = 0.5;
			main.c200x200.product.rotation = 0;
			main.c200x200.label.x = -33;
			main.c200x200.label.y = 4;
			main.c200x200.label.scale = 0.43;
			main.c200x200.label.rotation = 0;
			main.c200x200.slogan.x = -32.95;
			main.c200x200.slogan.y = -40.7;
			main.c200x200.slogan.scale = 0.7;
			main.c200x200.slogan.rotation = 0;
			main.c200x200.discount.x = 50.5;
			main.c200x200.discount.y = -26.65;
			main.c200x200.discount.scale = 0.6998;
			main.c200x200.discount.rotation = -3.8119;
		}
		
		////////////  09_c250x250  ////////////
		if(c250x250 == true){ 
			main.c250x250.product.x = 56;
			main.c250x250.product.y = 50.8;
			main.c250x250.product.scale = 0.6;
			main.c250x250.product.rotation = 0;
			main.c250x250.label.x = -38;
			main.c250x250.label.y = 6;
			main.c250x250.label.scale = 0.5594;
			main.c250x250.label.rotation = 0;
			main.c250x250.slogan.x = -41.9;
			main.c250x250.slogan.y = -51.1;
			main.c250x250.slogan.scale = 0.8609;
			main.c250x250.slogan.rotation = 0;
			main.c250x250.discount.x = 60.75;
			main.c250x250.discount.y = -34.4;
			main.c250x250.discount.scale = 0.8607;
			main.c250x250.discount.rotation = -3.8118;
		}
		
		////////////  10_c300x300  ////////////
		if(c300x300 == true){ 
			main.c300x300.product.x = 59;
			main.c300x300.product.y = 68;
			main.c300x300.product.scale = 0.8;
			main.c300x300.product.rotation = 0;
			main.c300x300.label.x = -50;
			main.c300x300.label.y = -3;
			main.c300x300.label.scale = 0.6413;
			main.c300x300.label.rotation = 0;
			main.c300x300.slogan.x = -51;
			main.c300x300.slogan.y = -67.65;
			main.c300x300.slogan.scale = 1.0499;
			main.c300x300.slogan.rotation = 0;
			main.c300x300.discount.x = 72.75;
			main.c300x300.discount.y = -46.45;
			main.c300x300.discount.scale = 1.0497;
			main.c300x300.discount.rotation = -3.8116;
		}
		
		////////////  11_c300x250  ////////////
		if(c300x250 == true){ 
			main.c300x250.product.x = 68;
			main.c300x250.product.y = 44.25;
			main.c300x250.product.scale = 0.73;
			main.c300x250.product.rotation = 0;
			main.c300x250.label.x = -54.5;
			main.c300x250.label.y = 17.25;
			main.c300x250.label.scale = 0.6001;
			main.c300x250.label.rotation = 0;
			main.c300x250.slogan.x = -59;
			main.c300x250.slogan.y = -44;
			main.c300x250.slogan.scale = 0.95;
			main.c300x250.slogan.rotation = 0;
			main.c300x250.discount.x = -16.45;
			main.c300x250.discount.y = -19.85;
			main.c300x250.discount.scale = 0.7998;
			main.c300x250.discount.rotation = -3.7652;
		}
		
		////////////  12_c336x280  ////////////
		if(c336x280 == true){ 
			main.c336x280.product.x = 79;
			main.c336x280.product.y = 58.85;
			main.c336x280.product.scale = 0.78;
			main.c336x280.product.rotation = 0;
			main.c336x280.label.x = -55.8;
			main.c336x280.label.y = 23;
			main.c336x280.label.scale = 0.7001;
			main.c336x280.label.rotation = 0;
			main.c336x280.slogan.x = -66.15;
			main.c336x280.slogan.y = -47;
			main.c336x280.slogan.scale = 1.0544;
			main.c336x280.slogan.rotation = 0;
			main.c336x280.discount.x = -19;
			main.c336x280.discount.y = -16.8;
			main.c336x280.discount.scale = 0.8878;
			main.c336x280.discount.rotation = -3.7647;
		}
		
		////////////  13_c480x320  ////////////
		if(c480x320 == true){ 
			main.c480x320.product.x = 120.75;
			main.c480x320.product.y = 58;
			main.c480x320.product.scale = 1.03;
			main.c480x320.product.rotation = 0;
			main.c480x320.label.x = -91;
			main.c480x320.label.y = 51;
			main.c480x320.label.scale = 0.94;
			main.c480x320.label.rotation = 0;
			main.c480x320.slogan.x = -108;
			main.c480x320.slogan.y = -41;
			main.c480x320.slogan.scale = 1.37;
			main.c480x320.slogan.rotation = 0;
			main.c480x320.discount.x = -36.45;
			main.c480x320.discount.y = -12.6;
			main.c480x320.discount.scale = 1.0998;
			main.c480x320.discount.rotation = -3.755;
		}
		
		////////////  14_c580x400  ////////////
		if(c580x400 == true){ 
			main.c580x400.product.x = 139;
			main.c580x400.product.y = 76;
			main.c580x400.product.scale = 1.34;
			main.c580x400.product.rotation = 0;
			main.c580x400.label.x = -114;
			main.c580x400.label.y = 55;
			main.c580x400.label.scale = 1.11;
			main.c580x400.label.rotation = 0;
			main.c580x400.slogan.x = -130.55;
			main.c580x400.slogan.y = -56;
			main.c580x400.slogan.scale = 1.6302;
			main.c580x400.slogan.rotation = 0;
			main.c580x400.discount.x = -44.55;
			main.c580x400.discount.y = -16.3;
			main.c580x400.discount.scale = 1.3087;
			main.c580x400.discount.rotation = -3.7545;
		}
		
		////////////  15_c970x250  ////////////
		if(c970x250 == true){ 
			main.c970x250.product.x = 319;
			main.c970x250.product.y = 10.9;
			main.c970x250.product.scale = 1.3599;
			main.c970x250.product.rotation = 0;
			main.c970x250.label.x = 43;
			main.c970x250.label.y = 47;
			main.c970x250.label.scale = 0.9802;
			main.c970x250.label.rotation = 0;
			main.c970x250.slogan.x = -274.45;
			main.c970x250.slogan.y = 45;
			main.c970x250.slogan.scale = 1.73;
			main.c970x250.slogan.rotation = 0;
			main.c970x250.discount.x = -179.6;
			main.c970x250.discount.y = 53.2;
			main.c970x250.discount.scale = 1.2997;
			main.c970x250.discount.rotation = -3.8129;
		}
		
		////////////  16_c1000x120  ////////////
		if(c1000x120 == true){ 
			main.c1000x120.product.x = 325;
			main.c1000x120.product.y = 0;
			main.c1000x120.product.scale = 0.7;
			main.c1000x120.product.rotation = 0;
			main.c1000x120.label.x = 174;
			main.c1000x120.label.y = -2;
			main.c1000x120.label.scale = 0.73;
			main.c1000x120.label.rotation = 0;
			main.c1000x120.slogan.x = -46;
			main.c1000x120.slogan.y = 0;
			main.c1000x120.slogan.scale = 1.2552;
			main.c1000x120.slogan.rotation = 0;
			main.c1000x120.discount.x = -31.7;
			main.c1000x120.discount.y = 21.9;
			main.c1000x120.discount.scale = 1.041;
			main.c1000x120.discount.rotation = -3.8123;
		}
		
		////////////  17_c970x90  ////////////
		if(c970x90 == true){ 
			main.c970x90.product.x = 288.5;
			main.c970x90.product.y = -0.45;
			main.c970x90.product.scale = 0.56;
			main.c970x90.product.rotation = 0;
			main.c970x90.label.x = 134;
			main.c970x90.label.y = -3;
			main.c970x90.label.scale = 0.6601;
			main.c970x90.label.rotation = 0;
			main.c970x90.slogan.x = -89.4;
			main.c970x90.slogan.y = -0.15;
			main.c970x90.slogan.scale = 1.2178;
			main.c970x90.slogan.rotation = 0;
			main.c970x90.discount.x = -3.75;
			main.c970x90.discount.y = 13.05;
			main.c970x90.discount.scale = 0.9473;
			main.c970x90.discount.rotation = -3.8117;
		}
		
		////////////  18_c728x90  ////////////
		if(c728x90 == true){ 
			main.c728x90.product.x = 238;
			main.c728x90.product.y = -3;
			main.c728x90.product.scale = 0.48;
			main.c728x90.product.rotation = 0;
			main.c728x90.label.x = 129;
			main.c728x90.label.y = -3;
			main.c728x90.label.scale = 0.5702;
			main.c728x90.label.rotation = 0;
			main.c728x90.slogan.x = -34.5;
			main.c728x90.slogan.y = -0.35;
			main.c728x90.slogan.scale = 0.8605;
			main.c728x90.slogan.rotation = 0;
			main.c728x90.discount.x = 8.85;
			main.c728x90.discount.y = 14.95;
			main.c728x90.discount.scale = 0.8431;
			main.c728x90.discount.rotation = -3.8117;
		}
		
		////////////  19_c468x60  ////////////
		if(c468x60 == true){ 
			main.c468x60.product.x = 154;
			main.c468x60.product.y = -4;
			main.c468x60.product.scale = 0.31;
			main.c468x60.product.rotation = 0;
			main.c468x60.label.x = 78.4;
			main.c468x60.label.y = -3;
			main.c468x60.label.scale = 0.3701;
			main.c468x60.label.rotation = 0;
			main.c468x60.slogan.x = -20;
			main.c468x60.slogan.y = -0.2;
			main.c468x60.slogan.scale = 0.53;
			main.c468x60.slogan.rotation = 0;
			main.c468x60.discount.x = 4;
			main.c468x60.discount.y = 9;
			main.c468x60.discount.scale = 0.522;
			main.c468x60.discount.rotation = -3.8098;
		}
		
		////////////  20_c320x100  ////////////
		if(c320x100 == true){ 
			main.c320x100.product.x = 106;
			main.c320x100.product.y = 2.7;
			main.c320x100.product.scale = 0.48;
			main.c320x100.product.rotation = 0;
			main.c320x100.label.x = 17;
			main.c320x100.label.y = 12.1;
			main.c320x100.label.scale = 0.3601;
			main.c320x100.label.rotation = 0;
			main.c320x100.slogan.x = -93.9;
			main.c320x100.slogan.y = 16;
			main.c320x100.slogan.scale = 0.6327;
			main.c320x100.slogan.rotation = 0;
			main.c320x100.discount.x = -60.8;
			main.c320x100.discount.y = 26.3;
			main.c320x100.discount.scale = 0.556;
			main.c320x100.discount.rotation = -3.7637;
		}
		
		////////////  21_c320x50  ////////////
		if(c320x50 == true){ 
			main.c320x50.product.x = 127;
			main.c320x50.product.y = -1.8;
			main.c320x50.product.scale = 0.27;
			main.c320x50.product.rotation = 0;
			main.c320x50.label.x = 65;
			main.c320x50.label.y = -3;
			main.c320x50.label.scale = 0.2801;
			main.c320x50.label.rotation = 0;
			main.c320x50.slogan.x = -16.85;
			main.c320x50.slogan.y = -0.8;
			main.c320x50.slogan.scale = 0.4504;
			main.c320x50.slogan.rotation = 0;
			main.c320x50.discount.x = 3.6;
			main.c320x50.discount.y = 6.7;
			main.c320x50.discount.scale = 0.4071;
			main.c320x50.discount.rotation = -3.8081;
		}
		
		////////////  22_c400x90  ////////////
		if(c400x90 == true){ 
			main.c400x90.product.x = 110;
			main.c400x90.product.y = -7;
			main.c400x90.product.scale = 0.43;
			main.c400x90.product.rotation = 0;
			main.c400x90.label.x = 6;
			main.c400x90.label.y = 17;
			main.c400x90.label.scale = 0.3501;
			main.c400x90.label.rotation = 0;
			main.c400x90.slogan.x = -128;
			main.c400x90.slogan.y = 20;
			main.c400x90.slogan.scale = 0.729;
			main.c400x90.slogan.rotation = 0;
			main.c400x90.discount.x = -89.6;
			main.c400x90.discount.y = 23.6;
			main.c400x90.discount.scale = 0.5998;
			main.c400x90.discount.rotation = -3.766;
		}
		
		////////////  23_c600x250  ////////////
		if(c600x250 == true){ 
			main.c600x250.product.x = 120;
			main.c600x250.product.y = 40;
			main.c600x250.product.scale = 1.08;
			main.c600x250.product.rotation = 0;
			main.c600x250.label.x = -106;
			main.c600x250.label.y = 58;
			main.c600x250.label.scale = 0.901;
			main.c600x250.label.rotation = 0;
			main.c600x250.slogan.x = -132;
			main.c600x250.slogan.y = -23;
			main.c600x250.slogan.scale = 1.17;
			main.c600x250.slogan.rotation = 0;
			main.c600x250.discount.x = 6.9;
			main.c600x250.discount.y = 56.8;
			main.c600x250.discount.scale = 1.1097;
			main.c600x250.discount.rotation = -3.7543;
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// BORDERS
	this.BORDER_R = new lib.BORDER();
	this.BORDER_R.name = "BORDER_R";
	this.BORDER_R.setTransform(-1000.7,-1000.5,0.9999,1,0,90,-90,0.5,0.7);

	this.BORDER_B = new lib.BORDER();
	this.BORDER_B.name = "BORDER_B";
	this.BORDER_B.setTransform(-1000.6,-1000.6,0.9999,1,180,0,0,0.6,0.6);

	this.BORDER_L = new lib.BORDER();
	this.BORDER_L.name = "BORDER_L";
	this.BORDER_L.setTransform(-1000.4,-1000.4,0.9999,1,0,-90,90,-0.4,-0.4);

	this.BORDER_T = new lib.BORDER();
	this.BORDER_T.name = "BORDER_T";
	this.BORDER_T.setTransform(-1000.5,-1000.2,0.9999,1,0,0,0,-0.5,-0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.BORDER_T},{t:this.BORDER_L},{t:this.BORDER_B},{t:this.BORDER_R}]}).wait(1));

	// CONTAINER
	this.c240x400 = new lib._07_CONTAINER_240x400();
	this.c240x400.name = "c240x400";
	this.c240x400.setTransform(120,200);

	this.timeline.addTween(cjs.Tween.get(this.c240x400).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-2878.8,-2798.8,3877.7000000000003,3797.7000000000003);
// library properties:
lib.properties = {
	id: '21128C3585604202A1E3744EE4B08C93',
	width: 240,
	height: 400,
	fps: 25,
	color: "#FFFFFF",
	opacity: 0.00,
	manifest: [
		{src:"index_atlas_P_1.png", id:"index_atlas_P_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['21128C3585604202A1E3744EE4B08C93'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;